/**
 * Web Audio API synthesized campus chime for high-priority & urgent notices.
 * Generates an elegant, warm 3-note institutional chime (C5 -> E5 -> G5)
 * without requiring any external mp3 files.
 */
export function playCampusChime(type: 'urgent' | 'regular' = 'urgent'): void {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const now = ctx.currentTime;
    const notes = type === 'urgent' ? [523.25, 659.25, 783.99, 1046.5] : [523.25, 659.25]; // C5, E5, G5, C6
    const noteDuration = 0.22;

    notes.forEach((freq, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + index * noteDuration);

      // Attack and gentle decay
      gain.gain.setValueAtTime(0.001, now + index * noteDuration);
      gain.gain.exponentialRampToValueAtTime(0.2, now + index * noteDuration + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + index * noteDuration + 0.6);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now + index * noteDuration);
      osc.stop(now + index * noteDuration + 0.65);
    });
  } catch (e) {
    console.warn('Audio chime could not be played:', e);
  }
}
