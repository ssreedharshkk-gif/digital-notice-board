export type NoticeCategory =
  | 'academic'
  | 'athletics'
  | 'arts_clubs'
  | 'administrative'
  | 'emergency'
  | 'exam_schedule';

export type NoticePriority = 'urgent' | 'high' | 'normal' | 'low';

export type TargetGrade =
  | 'all'
  | 'middle_school'
  | 'grade_9'
  | 'grade_10'
  | 'grade_11'
  | 'grade_12'
  | 'faculty';

export interface NoticePollOption {
  id: string;
  text: string;
  votes: number;
}

export interface NoticePoll {
  question: string;
  options: NoticePollOption[];
  totalVotes: number;
  voters?: Record<string, string>; // userId -> optionId
}

export interface NoticeAttachment {
  name: string;
  size: string;
  type: 'pdf' | 'doc' | 'image' | 'link';
  downloadLabel?: string;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  category: NoticeCategory;
  priority: NoticePriority;
  targetGrade: TargetGrade;
  targetDepartment?: string;
  authorName: string;
  authorRole: string;
  createdAt: string; // ISO string
  pinned: boolean;
  eventDate?: string;
  eventLocation?: string;
  poll?: NoticePoll;
  attachments?: NoticeAttachment[];
  acknowledgments: string[]; // student userIds
  reactions: {
    helpful: number;
    saved: number;
    applause: number;
    attending: number;
  };
  userReactions?: Record<string, string[]>; // userId -> array of reaction types
}

export interface UserProfile {
  id: string;
  name: string;
  role: 'teacher' | 'student';
  title: string;
  grade?: string; // e.g. "grade_11"
  department?: string;
  email?: string;
}

export interface OnlinePresence {
  total: number;
  teachers: number;
  students: number;
}
