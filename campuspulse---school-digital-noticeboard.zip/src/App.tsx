/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Search,
  Filter,
  PlusCircle,
  Bell,
  Radio,
  Sparkles,
  Layers,
  Calendar,
  AlertTriangle,
  RotateCcw,
  CheckCircle,
  X,
  Volume2,
  VolumeX,
} from 'lucide-react';
import type {
  Notice,
  NoticeAttachment,
  NoticeCategory,
  OnlinePresence,
  TargetGrade,
  UserProfile,
} from './types.ts';
import { wsClient } from './services/websocket.ts';
import { playCampusChime } from './utils/audio.ts';
import { TopBar } from './components/TopBar.tsx';
import { BellScheduleWidget } from './components/BellScheduleWidget.tsx';
import { NoticeCard } from './components/NoticeCard.tsx';
import { NoticeFormModal } from './components/NoticeFormModal.tsx';
import { AttachmentViewerModal } from './components/AttachmentViewerModal.tsx';
import { AcknowledgmentRosterModal } from './components/AcknowledgmentRosterModal.tsx';
import { BackpackDrawer } from './components/BackpackDrawer.tsx';
import { ProfileSwitcherModal } from './components/ProfileSwitcherModal.tsx';
import { HallwayKiosk } from './components/HallwayKiosk.tsx';

// Default initial teacher profile
const DEFAULT_USER: UserProfile = {
  id: 'teacher-thorne',
  name: 'Dr. Aris Thorne',
  role: 'teacher',
  title: 'Science Dept Chair & AP Chemistry Instructor',
  department: 'Natural Sciences',
  email: 'a.thorne@oakridge.edu',
};

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile>(DEFAULT_USER);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [onlinePresence, setOnlinePresence] = useState<OnlinePresence>({
    total: 24,
    teachers: 4,
    students: 20,
  });
  const [isConnected, setIsConnected] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Filters & Search
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [onlyUrgent, setOnlyUrgent] = useState(false);

  // Modals & Drawers
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingNotice, setEditingNotice] = useState<Notice | null>(null);
  const [activeAttachment, setActiveAttachment] = useState<NoticeAttachment | null>(null);
  const [rosterNotice, setRosterNotice] = useState<Notice | null>(null);
  const [isBackpackOpen, setIsBackpackOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isKioskMode, setIsKioskMode] = useState(false);

  // Live Toast Notification for real-time announcements
  const [liveToast, setLiveToast] = useState<{
    notice: Notice;
    timestamp: number;
  } | null>(null);

  // Connect to WebSocket and initialize listeners
  useEffect(() => {
    // Initial fetch fallback for instant response
    fetch('/api/notices')
      .then((res) => res.json())
      .then((data) => {
        if (data.notices && Array.isArray(data.notices)) {
          setNotices(data.notices);
        }
        if (data.onlineCount) {
          setOnlinePresence(data.onlineCount);
        }
      })
      .catch((err) => {
        console.warn('Initial REST fetch fallback error:', err);
      });

    // Start WebSocket connection
    wsClient.connect(currentUser);

    const unsubConn = wsClient.on('connection_change', ({ status }) => {
      setIsConnected(status === 'connected');
    });

    const unsubInit = wsClient.on('initial_state', (payload) => {
      if (payload.notices) setNotices(payload.notices);
      if (payload.onlineCount) setOnlinePresence(payload.onlineCount);
    });

    const unsubPresence = wsClient.on('presence_updated', (payload) => {
      if (payload.onlineCount) setOnlinePresence(payload.onlineCount);
    });

    const unsubCreate = wsClient.on('notice_created', (payload) => {
      if (payload.notice) {
        setNotices((prev) => [payload.notice, ...prev.filter((n) => n.id !== payload.notice.id)]);

        // Trigger real-time audio chime & live alert toast
        if (soundEnabled) {
          playCampusChime(payload.notice.priority === 'urgent' ? 'urgent' : 'regular');
        }

        setLiveToast({
          notice: payload.notice,
          timestamp: Date.now(),
        });
      }
    });

    const unsubUpdate = wsClient.on('notice_updated', (payload) => {
      if (payload.notice) {
        setNotices((prev) =>
          prev.map((n) => (n.id === payload.notice.id ? { ...n, ...payload.notice } : n))
        );
      }
    });

    const unsubDelete = wsClient.on('notice_deleted', (payload) => {
      if (payload.id) {
        setNotices((prev) => prev.filter((n) => n.id !== payload.id));
      }
    });

    const unsubPin = wsClient.on('notice_pinned', (payload) => {
      setNotices((prev) =>
        prev.map((n) => (n.id === payload.id ? { ...n, pinned: payload.pinned } : n))
      );
    });

    const unsubAck = wsClient.on('notice_acknowledged', (payload) => {
      setNotices((prev) =>
        prev.map((n) => (n.id === payload.id ? { ...n, acknowledgments: payload.acknowledgments } : n))
      );
    });

    const unsubReact = wsClient.on('notice_reacted', (payload) => {
      setNotices((prev) =>
        prev.map((n) => {
          if (n.id === payload.id) {
            const updatedUserReactions = { ...(n.userReactions || {}) };
            if (payload.userId && payload.userReactions) {
              updatedUserReactions[payload.userId] = payload.userReactions;
            }
            return {
              ...n,
              reactions: payload.reactions,
              userReactions: updatedUserReactions,
            };
          }
          return n;
        })
      );
    });

    const unsubPoll = wsClient.on('poll_voted', (payload) => {
      setNotices((prev) =>
        prev.map((n) => (n.id === payload.id ? { ...n, poll: payload.poll } : n))
      );
    });

    return () => {
      unsubConn();
      unsubInit();
      unsubPresence();
      unsubCreate();
      unsubUpdate();
      unsubDelete();
      unsubPin();
      unsubAck();
      unsubReact();
      unsubPoll();
    };
  }, [currentUser, soundEnabled]);

  // Dismiss live toast after 6 seconds
  useEffect(() => {
    if (!liveToast) return;
    const timer = setTimeout(() => setLiveToast(null), 6000);
    return () => clearTimeout(timer);
  }, [liveToast]);

  // Handle user profile changes
  const handleSelectUser = (newUser: UserProfile) => {
    setCurrentUser(newUser);
    wsClient.updatePresenceUser(newUser);
  };

  // Actions
  const handleCreateNotice = (noticeData: any) => {
    const success = wsClient.sendMessage({
      type: 'create_notice',
      notice: noticeData,
    });
    // Fallback if WS disconnected
    if (!success) {
      fetch('/api/notices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(noticeData),
      })
        .then((res) => res.json())
        .then((created) => {
          setNotices((prev) => [created, ...prev]);
        })
        .catch(console.error);
    }
  };

  const handleUpdateNotice = (noticeData: any) => {
    wsClient.sendMessage({
      type: 'update_notice',
      notice: noticeData,
    });
    setEditingNotice(null);
  };

  const handleDeleteNotice = (id: string) => {
    if (window.confirm('Are you sure you want to delete this notice?')) {
      wsClient.sendMessage({
        type: 'delete_notice',
        id,
      });
    }
  };

  const handleTogglePin = (id: string) => {
    wsClient.sendMessage({
      type: 'toggle_pin',
      id,
    });
  };

  const handleAcknowledge = useCallback(
    (id: string) => {
      wsClient.sendMessage({
        type: 'acknowledge_notice',
        id,
        userId: currentUser.id,
      });
    },
    [currentUser.id]
  );

  const handleReact = useCallback(
    (id: string, reactionType: 'helpful' | 'saved' | 'applause' | 'attending') => {
      wsClient.sendMessage({
        type: 'react_notice',
        id,
        reactionType,
        userId: currentUser.id,
      });
    },
    [currentUser.id]
  );

  const handleVotePoll = useCallback(
    (noticeId: string, optionId: string) => {
      wsClient.sendMessage({
        type: 'vote_poll',
        noticeId,
        optionId,
        userId: currentUser.id,
      });
    },
    [currentUser.id]
  );

  // Student saved notices in backpack
  const savedNotices = useMemo(() => {
    return notices.filter((n) => n.userReactions?.[currentUser.id]?.includes('saved'));
  }, [notices, currentUser.id]);

  // Filtered and sorted notices
  const filteredNotices = useMemo(() => {
    return notices.filter((n) => {
      // Category filter
      if (selectedCategory !== 'all' && n.category !== selectedCategory) {
        return false;
      }
      // Grade filter
      if (selectedGrade !== 'all' && n.targetGrade !== 'all' && n.targetGrade !== selectedGrade) {
        return false;
      }
      // Urgent filter
      if (onlyUrgent && n.priority !== 'urgent') {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = n.title.toLowerCase().includes(query);
        const matchesContent = n.content.toLowerCase().includes(query);
        const matchesAuthor = n.authorName.toLowerCase().includes(query);
        const matchesDept = (n.targetDepartment || '').toLowerCase().includes(query);
        return matchesTitle || matchesContent || matchesAuthor || matchesDept;
      }
      return true;
    });
  }, [notices, selectedCategory, selectedGrade, onlyUrgent, searchQuery]);

  // Pinned vs standard notices
  const pinnedNotices = useMemo(() => {
    return filteredNotices.filter((n) => n.pinned);
  }, [filteredNotices]);

  const regularNotices = useMemo(() => {
    return filteredNotices.filter((n) => !n.pinned);
  }, [filteredNotices]);

  // Urgent active advisories count
  const urgentCount = useMemo(() => {
    return notices.filter((n) => n.priority === 'urgent').length;
  }, [notices]);

  // If Hallway Kiosk Mode is active
  if (isKioskMode) {
    return (
      <HallwayKiosk
        notices={notices}
        onClose={() => setIsKioskMode(false)}
        onlineCount={onlinePresence}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* 3-Zone Top Navigation Bar */}
      <TopBar
        currentUser={currentUser}
        activeCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        onOpenCreateModal={() => {
          setEditingNotice(null);
          setIsCreateModalOpen(true);
        }}
        onOpenBackpack={() => setIsBackpackOpen(true)}
        onOpenProfileSwitcher={() => setIsProfileModalOpen(true)}
        onToggleKiosk={() => setIsKioskMode(true)}
        savedCount={savedNotices.length}
      />

      {/* Real-time Connection & Live Presence Sub-Bar */}
      <div className="bg-white border-b border-slate-200/80 px-6 py-2.5 flex items-center justify-between gap-4 text-xs text-slate-600 flex-wrap">
        <div className="flex items-center gap-3">
          {/* Live sync pulse indicator */}
          <div className="flex items-center gap-1.5 font-medium text-slate-700">
            <span
              className={`w-2 h-2 rounded-full ${
                isConnected ? 'bg-emerald-500' : 'bg-amber-500 animate-pulse'
              }`}
            />
            <span>{isConnected ? 'Real-Time Sync Active' : 'Connecting to Server...'}</span>
          </div>
          <span aria-hidden="true" className="text-slate-300">|</span>

          {/* Connected audience count */}
          <div className="flex items-center gap-1.5 text-slate-600 font-mono tabular-nums">
            <Radio className="w-3.5 h-3.5 text-indigo-600" />
            <span>
              {onlinePresence.total} Connected ({onlinePresence.teachers} Faculty · {onlinePresence.students} Students)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4">
          {/* Audio Chime toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className="flex items-center gap-1 text-slate-500 hover:text-slate-800 transition-colors"
            title={soundEnabled ? 'Campus chime enabled for alerts' : 'Campus chime muted'}
          >
            {soundEnabled ? (
              <>
                <Volume2 className="w-3.5 h-3.5 text-indigo-600" />
                <span className="hidden sm:inline">Sound Chime On</span>
              </>
            ) : (
              <>
                <VolumeX className="w-3.5 h-3.5 text-slate-400" />
                <span className="hidden sm:inline">Muted</span>
              </>
            )}
          </button>

          {/* Active Profile Info */}
          <div className="flex items-center gap-2">
            <span className="text-slate-400 hidden sm:inline">Viewing as:</span>
            <button
              onClick={() => setIsProfileModalOpen(true)}
              className="font-semibold text-slate-800 hover:text-indigo-600 underline underline-offset-4 transition-colors"
            >
              {currentUser.name} ({currentUser.role === 'teacher' ? 'Faculty' : 'Student'})
            </button>
          </div>
        </div>
      </div>

      {/* Floating Live Toast Announcement Banner (WebSocket real-time broadcast) */}
      {liveToast && (
        <div className="fixed top-18 right-6 z-40 max-w-md w-full bg-slate-900 text-white rounded-2xl p-4 shadow-2xl border border-slate-700 flex items-start justify-between gap-3 animate-bounce">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500 flex items-center justify-center shrink-0">
              <Bell className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="text-xs font-semibold text-indigo-300 uppercase tracking-wide">
                Live Notice Broadcast
              </div>
              <div className="text-sm font-bold text-white mt-0.5 line-clamp-1">
                {liveToast.notice.title}
              </div>
              <div className="text-xs text-slate-300 line-clamp-1 mt-0.5">
                From {liveToast.notice.authorName} · {liveToast.notice.authorRole}
              </div>
            </div>
          </div>
          <button
            onClick={() => setLiveToast(null)}
            className="text-slate-400 hover:text-white p-1 rounded-md"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 flex-1 flex flex-col gap-6">
        {/* Institutional Campus Header Strip */}
        <section className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          <div className="lg:col-span-8 flex items-start gap-5">
            <img
              src="/src/assets/images/school_emblem_crest_1791618934698.jpg"
              alt="Oakridge Academy Seal"
              referrerPolicy="no-referrer"
              className="w-16 h-16 rounded-xl object-cover border border-slate-200 shadow-xs shrink-0 hidden sm:block"
            />
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
                <span>Oakridge Academy Digital Commons</span>
                <span aria-hidden="true">·</span>
                <span>Fall Semester 2026</span>
                <span aria-hidden="true">·</span>
                <span className="text-indigo-600 font-semibold">Live Bulletin</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Official Campus Digital Noticeboard
              </h1>
              <p className="text-sm text-slate-600 mt-1 max-w-2xl leading-relaxed">
                Real-time official announcements, laboratory schedules, athletic tryouts, and emergency advisories published by faculty and broadcast instantly to students.
              </p>
            </div>
          </div>

          {/* Quick Metrics Strip */}
          <div className="lg:col-span-4 flex items-center justify-between lg:justify-end gap-6 pt-4 lg:pt-0 border-t lg:border-t-0 border-slate-100">
            <div className="text-center lg:text-right">
              <div className="text-2xl font-bold font-mono tabular-nums text-slate-900">
                {notices.length}
              </div>
              <div className="text-xs text-slate-500 font-medium">Active Notices</div>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <div className="text-center lg:text-right">
              <div className={`text-2xl font-bold font-mono tabular-nums ${urgentCount > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
                {urgentCount}
              </div>
              <div className="text-xs text-slate-500 font-medium">Urgent Advisories</div>
            </div>
            <div className="h-8 w-px bg-slate-200" />
            <div className="text-center lg:text-right">
              <div className="text-2xl font-bold font-mono tabular-nums text-indigo-600">
                {onlinePresence.total}
              </div>
              <div className="text-xs text-slate-500 font-medium">Active Readers</div>
            </div>
          </div>
        </section>

        {/* Live Bell Schedule Widget */}
        <BellScheduleWidget />

        {/* Filter & Search Deck */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          {/* Search bar */}
          <div className="relative flex-1 min-w-[240px]">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search announcements, subjects, teachers, or venues..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 text-slate-900"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Interactive filter controls (Buttons & Selectors allowed per Section 1A) */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Category Filter dropdown */}
            <div className="flex items-center gap-1.5 text-xs text-slate-600">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-800 font-medium"
              >
                <option value="all">All Categories</option>
                <option value="academic">Academic & Labs</option>
                <option value="athletics">Athletics & Teams</option>
                <option value="arts_clubs">Clubs & Arts</option>
                <option value="administrative">Campus Admin</option>
                <option value="emergency">Urgent Advisories</option>
                <option value="exam_schedule">Exams & Schedule</option>
              </select>
            </div>

            {/* Target Grade Filter */}
            <select
              value={selectedGrade}
              onChange={(e) => setSelectedGrade(e.target.value)}
              className="px-2.5 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 text-slate-800 font-medium"
            >
              <option value="all">Target: All Grades</option>
              <option value="grade_9">Grade 9 (Freshmen)</option>
              <option value="grade_10">Grade 10 (Sophomores)</option>
              <option value="grade_11">Grade 11 (Juniors)</option>
              <option value="grade_12">Grade 12 (Seniors)</option>
              <option value="middle_school">Middle School</option>
              <option value="faculty">Faculty Only</option>
            </select>

            {/* Urgent only button */}
            <button
              onClick={() => setOnlyUrgent(!onlyUrgent)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors flex items-center gap-1.5 ${
                onlyUrgent
                  ? 'bg-rose-50 border-rose-300 text-rose-700'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <AlertTriangle className={`w-3.5 h-3.5 ${onlyUrgent ? 'text-rose-600' : 'text-slate-400'}`} />
              <span>Urgent Only</span>
            </button>

            {/* Quick reset filters */}
            {(selectedCategory !== 'all' || selectedGrade !== 'all' || onlyUrgent || searchQuery) && (
              <button
                onClick={() => {
                  setSelectedCategory('all');
                  setSelectedGrade('all');
                  setOnlyUrgent(false);
                  setSearchQuery('');
                }}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
                title="Reset all filters"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Notices Section */}
        <div className="space-y-6">
          {/* Pinned Announcements Block */}
          {pinnedNotices.length > 0 && (
            <section className="space-y-3">
              <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
                <span>Pinned & Featured Notices ({pinnedNotices.length})</span>
              </div>
              <div className="grid grid-cols-1 gap-4">
                {pinnedNotices.map((notice) => (
                  <NoticeCard
                    key={notice.id}
                    notice={notice}
                    currentUser={currentUser}
                    onAcknowledge={handleAcknowledge}
                    onReact={handleReact}
                    onVotePoll={handleVotePoll}
                    onOpenAttachment={setActiveAttachment}
                    onTogglePin={handleTogglePin}
                    onEditNotice={(n) => {
                      setEditingNotice(n);
                      setIsCreateModalOpen(true);
                    }}
                    onDeleteNotice={handleDeleteNotice}
                    onViewRoster={setRosterNotice}
                  />
                ))}
              </div>
            </section>
          )}

          {/* Regular Announcements Stream */}
          <section className="space-y-3">
            <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-500">
              <span>
                {pinnedNotices.length > 0 ? 'All Campus Notices' : 'Announcements Stream'} ({regularNotices.length})
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                Sorted by most recent
              </span>
            </div>

            {filteredNotices.length === 0 ? (
              <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
                <Layers className="w-12 h-12 text-slate-300 mx-auto" />
                <h3 className="text-base font-bold text-slate-800">No Announcements Found</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto leading-relaxed">
                  No notices match your active filter criteria. Try clearing search keywords or selecting all categories.
                </p>
                <button
                  onClick={() => {
                    setSelectedCategory('all');
                    setSelectedGrade('all');
                    setOnlyUrgent(false);
                    setSearchQuery('');
                  }}
                  className="px-4 py-2 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors inline-block"
                >
                  Clear All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4">
                {regularNotices.map((notice) => (
                  <NoticeCard
                    key={notice.id}
                    notice={notice}
                    currentUser={currentUser}
                    onAcknowledge={handleAcknowledge}
                    onReact={handleReact}
                    onVotePoll={handleVotePoll}
                    onOpenAttachment={setActiveAttachment}
                    onTogglePin={handleTogglePin}
                    onEditNotice={(n) => {
                      setEditingNotice(n);
                      setIsCreateModalOpen(true);
                    }}
                    onDeleteNotice={handleDeleteNotice}
                    onViewRoster={setRosterNotice}
                  />
                ))}
              </div>
            )}
          </section>
        </div>
      </main>

      {/* Modals and Drawers */}
      <NoticeFormModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setEditingNotice(null);
        }}
        onSubmit={editingNotice ? handleUpdateNotice : handleCreateNotice}
        currentUser={currentUser}
        initialNotice={editingNotice}
      />

      <AttachmentViewerModal
        attachment={activeAttachment}
        onClose={() => setActiveAttachment(null)}
      />

      <AcknowledgmentRosterModal
        notice={rosterNotice}
        onClose={() => setRosterNotice(null)}
      />

      <BackpackDrawer
        isOpen={isBackpackOpen}
        onClose={() => setIsBackpackOpen(false)}
        savedNotices={savedNotices}
        onRemoveSaved={(id) => handleReact(id, 'saved')}
        onSelectNotice={(id) => {
          const el = document.getElementById(id);
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }}
      />

      <ProfileSwitcherModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        currentUser={currentUser}
        onSelectUser={handleSelectUser}
      />
    </div>
  );
}
