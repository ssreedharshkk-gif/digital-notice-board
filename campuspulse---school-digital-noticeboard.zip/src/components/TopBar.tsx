import React from 'react';
import { PlusCircle, Bookmark, Monitor, UserCheck } from 'lucide-react';
import type { UserProfile } from '../types.ts';

interface TopBarProps {
  currentUser: UserProfile;
  activeCategory: string;
  onSelectCategory: (cat: string) => void;
  onOpenCreateModal: () => void;
  onOpenBackpack: () => void;
  onOpenProfileSwitcher: () => void;
  onToggleKiosk: () => void;
  savedCount: number;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentUser,
  activeCategory,
  onSelectCategory,
  onOpenCreateModal,
  onOpenBackpack,
  onOpenProfileSwitcher,
  onToggleKiosk,
  savedCount,
}) => {
  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-6 py-3.5 bg-white border-b border-slate-200">
      {/* Zone 1: Single text element wordmark */}
      <div className="flex items-center gap-3 shrink-0">
        <a
          href="#"
          onClick={(e) => {
            e.preventDefault();
            onSelectCategory('all');
          }}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-indigo-600 transition-colors flex items-center gap-2"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 shrink-0"></span>
          CampusPulse
        </a>
      </div>

      {/* Zone 2: 4-5 clean single-line text navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
        <button
          onClick={() => onSelectCategory('all')}
          className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
            activeCategory === 'all' ? 'text-indigo-600 font-semibold underline underline-offset-8' : ''
          }`}
        >
          All Notices
        </button>
        <button
          onClick={() => onSelectCategory('academic')}
          className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
            activeCategory === 'academic' ? 'text-indigo-600 font-semibold underline underline-offset-8' : ''
          }`}
        >
          Academic & Labs
        </button>
        <button
          onClick={() => onSelectCategory('athletics')}
          className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
            activeCategory === 'athletics' ? 'text-indigo-600 font-semibold underline underline-offset-8' : ''
          }`}
        >
          Athletics & Teams
        </button>
        <button
          onClick={() => onSelectCategory('arts_clubs')}
          className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
            activeCategory === 'arts_clubs' ? 'text-indigo-600 font-semibold underline underline-offset-8' : ''
          }`}
        >
          Clubs & Arts
        </button>
        <button
          onClick={() => onSelectCategory('emergency')}
          className={`hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 ${
            activeCategory === 'emergency' ? 'text-rose-600 font-semibold underline underline-offset-8' : ''
          }`}
        >
          Advisories
        </button>
      </nav>

      {/* Zone 3: 1 primary action */}
      <div className="flex items-center gap-3 shrink-0">
        <button
          onClick={onToggleKiosk}
          title="Switch to Hallway Kiosk display mode"
          className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <Monitor className="w-3.5 h-3.5 text-slate-500" />
          Hallway Display
        </button>

        <button
          onClick={onOpenProfileSwitcher}
          title="Switch active user profile"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
        >
          <UserCheck className="w-3.5 h-3.5 text-indigo-600" />
          <span className="max-w-[120px] truncate">{currentUser.name}</span>
        </button>

        {currentUser.role === 'teacher' ? (
          <button
            onClick={onOpenCreateModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 rounded-lg transition-colors shadow-sm whitespace-nowrap shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            Post Notice
          </button>
        ) : (
          <button
            onClick={onOpenBackpack}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg transition-colors whitespace-nowrap shrink-0"
          >
            <Bookmark className="w-4 h-4 text-indigo-600" />
            Backpack ({savedCount})
          </button>
        )}
      </div>
    </header>
  );
};
