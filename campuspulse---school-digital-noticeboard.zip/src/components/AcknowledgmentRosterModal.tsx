import React from 'react';
import { X, CheckCircle2, Users, Download } from 'lucide-react';
import type { Notice } from '../types.ts';

interface AcknowledgmentRosterModalProps {
  notice: Notice | null;
  onClose: () => void;
}

// Sample student directory for resolving student IDs to realistic student names
const STUDENT_DIRECTORY: Record<string, { name: string; grade: string; email: string }> = {
  'student-101': { name: 'Leo Vance', grade: 'Grade 11 (STEM Track)', email: 'l.vance@student.oakridge.edu' },
  'student-102': { name: 'Maya Patel', grade: 'Grade 10 (Fine Arts)', email: 'm.patel@student.oakridge.edu' },
  'student-103': { name: 'Jordan Smith', grade: 'Grade 12 (Senior)', email: 'j.smith@student.oakridge.edu' },
  'student-104': { name: 'Chris Evans', grade: 'Grade 9 (Freshman)', email: 'c.evans@student.oakridge.edu' },
  'student-105': { name: 'Aiden Tanaka', grade: 'Grade 11 (Athletics)', email: 'a.tanaka@student.oakridge.edu' },
  'student-106': { name: 'Sophia Chen', grade: 'Grade 11 (Honors)', email: 's.chen@student.oakridge.edu' },
  'student-107': { name: 'Noah Miller', grade: 'Grade 10', email: 'n.miller@student.oakridge.edu' },
  'student-108': { name: 'Olivia Rossi', grade: 'Grade 12 (Senior)', email: 'o.rossi@student.oakridge.edu' },
  'student-109': { name: 'Ethan Wright', grade: 'Grade 10', email: 'e.wright@student.oakridge.edu' },
  'student-112': { name: 'Emma Watson', grade: 'Grade 11', email: 'e.watson@student.oakridge.edu' },
};

export const AcknowledgmentRosterModal: React.FC<AcknowledgmentRosterModalProps> = ({
  notice,
  onClose,
}) => {
  if (!notice) return null;

  const ackCount = notice.acknowledgments.length;
  const estimatedTargetTotal = 32; // Standard class or cohort size
  const percentage = Math.min(100, Math.round((ackCount / estimatedTargetTotal) * 100));

  const exportRosterCsv = () => {
    const rows = [
      ['Student Name', 'Grade Track', 'Email', 'Status', 'Timestamp'],
      ...notice.acknowledgments.map((id) => {
        const student = STUDENT_DIRECTORY[id] || {
          name: `Student (${id})`,
          grade: 'Enrolled',
          email: `${id}@student.oakridge.edu`,
        };
        return [student.name, student.grade, student.email, 'Confirmed Read', new Date().toLocaleDateString()];
      }),
    ];
    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${notice.title.slice(0, 20)}_Read_Roster.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-xl w-full border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <CheckCircle2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900">Student Read Receipts & Roster</h3>
              <div className="text-xs text-slate-500 truncate max-w-sm">{notice.title}</div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stats strip */}
        <div className="px-6 py-4 bg-slate-50/50 border-b border-slate-200 flex items-center justify-between gap-4">
          <div>
            <div className="text-xs text-slate-500 font-medium">Cohort Acknowledgment Rate</div>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">{percentage}%</span>
              <span className="text-xs text-slate-500 font-mono tabular-nums">
                ({ackCount} of {estimatedTargetTotal} expected)
              </span>
            </div>
          </div>
          <button
            onClick={exportRosterCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors shadow-2xs shrink-0"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            Export CSV
          </button>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-slate-200 h-1.5">
          <div
            className="bg-emerald-500 h-1.5 transition-all duration-300"
            style={{ width: `${percentage}%` }}
          />
        </div>

        {/* Student list */}
        <div className="p-6 overflow-y-auto flex-1 space-y-2">
          {ackCount === 0 ? (
            <div className="text-center py-8 text-slate-400 text-sm">
              No students have marked this notice as read yet.
            </div>
          ) : (
            notice.acknowledgments.map((id, index) => {
              const student = STUDENT_DIRECTORY[id] || {
                name: `Student ID: ${id}`,
                grade: 'Active Student',
                email: `${id}@student.oakridge.edu`,
              };
              return (
                <div
                  key={id + index}
                  className="flex items-center justify-between p-3 rounded-lg border border-slate-200/80 bg-white hover:bg-slate-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-7 h-7 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-semibold text-slate-700">
                      {student.name.charAt(0)}
                    </div>
                    <div>
                      <div className="text-xs font-semibold text-slate-900">{student.name}</div>
                      <div className="text-[11px] text-slate-500">{student.grade}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
                      {student.email}
                    </span>
                    <span className="text-[11px] font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-sm border border-emerald-100 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Confirmed
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
