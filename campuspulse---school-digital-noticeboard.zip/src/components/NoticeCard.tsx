import React from 'react';
import {
  Pin,
  Calendar,
  MapPin,
  FileText,
  CheckCircle2,
  ThumbsUp,
  Bookmark,
  Sparkles,
  Users,
  AlertTriangle,
  MoreVertical,
  Trash2,
  Edit2,
  Eye,
} from 'lucide-react';
import type { Notice, NoticeAttachment, UserProfile } from '../types.ts';

interface NoticeCardProps {
  notice: Notice;
  currentUser: UserProfile;
  onAcknowledge: (id: string) => void;
  onReact: (id: string, reactionType: 'helpful' | 'saved' | 'applause' | 'attending') => void;
  onVotePoll: (noticeId: string, optionId: string) => void;
  onOpenAttachment: (att: NoticeAttachment) => void;
  onTogglePin?: (id: string) => void;
  onEditNotice?: (notice: Notice) => void;
  onDeleteNotice?: (id: string) => void;
  onViewRoster?: (notice: Notice) => void;
}

const CATEGORY_NAMES: Record<string, string> = {
  academic: 'Academic & Labs',
  athletics: 'Athletics & Teams',
  arts_clubs: 'Clubs & Arts',
  administrative: 'Campus Administration',
  emergency: 'Campus Advisory',
  exam_schedule: 'Exams & Schedule',
};

const GRADE_LABELS: Record<string, string> = {
  all: 'All Grades',
  middle_school: 'Middle School',
  grade_9: 'Grade 9',
  grade_10: 'Grade 10',
  grade_11: 'Grade 11',
  grade_12: 'Grade 12',
  faculty: 'Faculty Only',
};

export const NoticeCard: React.FC<NoticeCardProps> = ({
  notice,
  currentUser,
  onAcknowledge,
  onReact,
  onVotePoll,
  onOpenAttachment,
  onTogglePin,
  onEditNotice,
  onDeleteNotice,
  onViewRoster,
}) => {
  const [menuOpen, setMenuOpen] = React.useState(false);

  const isAcknowledged = notice.acknowledgments.includes(currentUser.id);
  const userReactions = notice.userReactions?.[currentUser.id] || [];
  const isSaved = userReactions.includes('saved');
  const isHelpful = userReactions.includes('helpful');
  const isApplause = userReactions.includes('applause');
  const isAttending = userReactions.includes('attending');

  const formatRelativeTime = (isoString: string) => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffMin = Math.floor(diffMs / (1000 * 60));
      if (diffMin < 1) return 'Just now';
      if (diffMin < 60) return `${diffMin}m ago`;
      const diffHours = Math.floor(diffMin / 60);
      if (diffHours < 24) return `${diffHours}h ago`;
      const diffDays = Math.floor(diffHours / 24);
      return `${diffDays}d ago`;
    } catch {
      return 'Recently';
    }
  };

  const isTeacher = currentUser.role === 'teacher';
  const isUrgent = notice.priority === 'urgent';
  const isHigh = notice.priority === 'high';

  return (
    <article
      className={`relative bg-white rounded-2xl border transition-shadow duration-200 p-6 ${
        isUrgent
          ? 'border-rose-300 ring-1 ring-rose-200/50 shadow-xs'
          : isHigh
          ? 'border-amber-200 shadow-xs'
          : 'border-slate-200/90 shadow-2xs hover:shadow-xs'
      }`}
    >
      {/* Pinned Marker / Top Line Indicator */}
      {notice.pinned && (
        <div className="flex items-center gap-1.5 text-xs font-semibold text-indigo-600 mb-3">
          <Pin className="w-3.5 h-3.5 fill-indigo-600" />
          <span>Pinned Announcement</span>
        </div>
      )}

      {/* Clean Unboxed Metadata Header (Zero-Pill Discipline) */}
      <div className="flex items-center justify-between gap-4 mb-2 text-xs text-slate-500">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-medium text-slate-700">
            {CATEGORY_NAMES[notice.category] || notice.category}
          </span>
          <span aria-hidden="true">·</span>
          <span>{GRADE_LABELS[notice.targetGrade] || notice.targetGrade}</span>
          {notice.targetDepartment && (
            <>
              <span aria-hidden="true">·</span>
              <span>{notice.targetDepartment}</span>
            </>
          )}
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">{formatRelativeTime(notice.createdAt)}</span>
        </div>

        {/* Priority Status Text indicator */}
        <div className="flex items-center gap-2 shrink-0">
          {isUrgent && (
            <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-600">
              <AlertTriangle className="w-3.5 h-3.5" /> Urgent Notice
            </span>
          )}
          {isHigh && !isUrgent && (
            <span className="text-xs font-semibold text-amber-600">
              High Priority
            </span>
          )}

          {/* Teacher management dropdown */}
          {isTeacher && (
            <div className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded-md hover:bg-slate-100 transition-colors"
                title="Announcement options"
              >
                <MoreVertical className="w-4 h-4" />
              </button>

              {menuOpen && (
                <div
                  className="absolute right-0 top-full mt-1 w-44 bg-white border border-slate-200 rounded-xl shadow-lg z-20 py-1 text-xs"
                  onClick={() => setMenuOpen(false)}
                >
                  {onTogglePin && (
                    <button
                      onClick={() => onTogglePin(notice.id)}
                      className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Pin className="w-3.5 h-3.5" />
                      <span>{notice.pinned ? 'Unpin from Top' : 'Pin to Top'}</span>
                    </button>
                  )}
                  {onViewRoster && (
                    <button
                      onClick={() => onViewRoster(notice)}
                      className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Read Receipts ({notice.acknowledgments.length})</span>
                    </button>
                  )}
                  {onEditNotice && (
                    <button
                      onClick={() => onEditNotice(notice)}
                      className="w-full text-left px-3 py-2 text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Edit Notice</span>
                    </button>
                  )}
                  {onDeleteNotice && (
                    <button
                      onClick={() => onDeleteNotice(notice.id)}
                      className="w-full text-left px-3 py-2 text-rose-600 hover:bg-rose-50 flex items-center gap-2"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete Notice</span>
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Title */}
      <h3 className="text-lg font-bold text-slate-900 tracking-tight leading-snug mb-3">
        {notice.title}
      </h3>

      {/* Body Content */}
      <div className="text-sm text-slate-700 leading-relaxed space-y-2 whitespace-pre-line mb-4">
        {notice.content}
      </div>

      {/* Event Details Strip (if scheduled) */}
      {(notice.eventDate || notice.eventLocation) && (
        <div className="mb-4 p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-slate-700">
          {notice.eventDate && (
            <div className="flex items-center gap-2">
              <Calendar className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <span className="font-medium font-mono tabular-nums">{notice.eventDate}</span>
            </div>
          )}
          {notice.eventLocation && (
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span>{notice.eventLocation}</span>
            </div>
          )}
        </div>
      )}

      {/* Interactive Poll Section */}
      {notice.poll && (
        <div className="mb-4 p-4 rounded-xl bg-slate-50/70 border border-slate-200">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-800 mb-2.5">
            <span>{notice.poll.question}</span>
            <span className="text-slate-500 font-mono tabular-nums font-normal">
              {notice.poll.totalVotes} responses
            </span>
          </div>

          <div className="space-y-2">
            {notice.poll.options.map((option) => {
              const myVotedOption = notice.poll?.voters?.[currentUser.id];
              const isSelected = myVotedOption === option.id;
              const total = notice.poll?.totalVotes || 1;
              const pct = notice.poll?.totalVotes ? Math.round((option.votes / total) * 100) : 0;

              return (
                <button
                  key={option.id}
                  onClick={() => onVotePoll(notice.id, option.id)}
                  className={`w-full relative text-left p-2.5 rounded-lg border text-xs transition-colors overflow-hidden ${
                    isSelected
                      ? 'border-indigo-400 bg-indigo-50/70 text-indigo-950 font-medium'
                      : 'border-slate-200 bg-white hover:bg-slate-100/60 text-slate-800'
                  }`}
                >
                  {/* Visual percentage fill background */}
                  <div
                    className={`absolute left-0 top-0 bottom-0 pointer-events-none transition-all duration-300 ${
                      isSelected ? 'bg-indigo-100/80' : 'bg-slate-100'
                    }`}
                    style={{ width: `${pct}%` }}
                  />

                  <div className="relative z-10 flex items-center justify-between gap-2">
                    <span className="flex items-center gap-2">
                      <span
                        className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 ${
                          isSelected ? 'border-indigo-600 bg-indigo-600' : 'border-slate-300'
                        }`}
                      >
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-white" />}
                      </span>
                      <span>{option.text}</span>
                    </span>
                    <span className="font-mono tabular-nums text-slate-500 shrink-0 font-medium">
                      {pct}% ({option.votes})
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Attachments Strip */}
      {notice.attachments && notice.attachments.length > 0 && (
        <div className="mb-4 space-y-2">
          <div className="text-xs font-semibold text-slate-700">Official Attachments:</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {notice.attachments.map((att, idx) => (
              <button
                key={idx}
                onClick={() => onOpenAttachment(att)}
                className="flex items-center justify-between p-2.5 bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-200 rounded-xl text-left transition-colors text-xs group"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div className="w-7 h-7 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                    <FileText className="w-3.5 h-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="font-medium text-slate-900 truncate">{att.name}</div>
                    <div className="text-[11px] text-slate-500 font-mono tabular-nums">{att.size}</div>
                  </div>
                </div>
                <span className="text-[11px] text-indigo-600 font-medium shrink-0 ml-2">
                  View PDF
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Footer Info: Author & Department */}
      <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-4 text-xs text-slate-500 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-slate-200 text-slate-700 flex items-center justify-center font-bold text-[10px]">
            {notice.authorName.charAt(0)}
          </div>
          <div>
            <span className="font-semibold text-slate-800">{notice.authorName}</span>
            <span aria-hidden="true" className="mx-1">·</span>
            <span className="text-slate-500">{notice.authorRole}</span>
          </div>
        </div>

        {/* Read Receipts Count for teachers */}
        {isTeacher && onViewRoster && (
          <button
            onClick={() => onViewRoster(notice)}
            className="text-indigo-600 hover:text-indigo-800 hover:underline font-mono tabular-nums text-xs"
          >
            {notice.acknowledgments.length} confirmed read
          </button>
        )}
      </div>

      {/* Action Strip: Acknowledge & Reactions */}
      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
        {/* Student Read Acknowledgment button */}
        <button
          onClick={() => onAcknowledge(notice.id)}
          className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
            isAcknowledged
              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
          }`}
          title={isAcknowledged ? 'You acknowledged this notice' : 'Mark as read'}
        >
          <CheckCircle2
            className={`w-3.5 h-3.5 ${isAcknowledged ? 'text-emerald-600' : 'text-slate-400'}`}
          />
          <span>{isAcknowledged ? 'Acknowledged' : "I've Read This"}</span>
          <span className="font-mono tabular-nums text-slate-500 font-normal">
            ({notice.acknowledgments.length})
          </span>
        </button>

        {/* Reaction Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onReact(notice.id, 'helpful')}
            className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
              isHelpful
                ? 'bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
            title="Mark as helpful"
          >
            <ThumbsUp className="w-3.5 h-3.5" />
            <span className="font-mono tabular-nums">{notice.reactions.helpful}</span>
          </button>

          <button
            onClick={() => onReact(notice.id, 'saved')}
            className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
              isSaved
                ? 'bg-amber-50 text-amber-700 border border-amber-200 font-medium'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
            title="Save to backpack"
          >
            <Bookmark className={`w-3.5 h-3.5 ${isSaved ? 'fill-amber-600' : ''}`} />
            <span className="font-mono tabular-nums">{notice.reactions.saved}</span>
          </button>

          <button
            onClick={() => onReact(notice.id, 'applause')}
            className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
              isApplause
                ? 'bg-purple-50 text-purple-700 border border-purple-200 font-medium'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
            title="Celebrate / Applause"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span className="font-mono tabular-nums">{notice.reactions.applause}</span>
          </button>

          {notice.eventDate && (
            <button
              onClick={() => onReact(notice.id, 'attending')}
              className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs transition-colors ${
                isAttending
                  ? 'bg-blue-50 text-blue-700 border border-blue-200 font-medium'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
              title="Attending this event"
            >
              <Users className="w-3.5 h-3.5" />
              <span>RSVP</span>
              <span className="font-mono tabular-nums">({notice.reactions.attending})</span>
            </button>
          )}
        </div>
      </div>
    </article>
  );
};
