import React from 'react';
import { X, FileText, Download, Check, ShieldCheck, Printer } from 'lucide-react';
import type { NoticeAttachment } from '../types.ts';

interface AttachmentViewerModalProps {
  attachment: NoticeAttachment | null;
  onClose: () => void;
}

export const AttachmentViewerModal: React.FC<AttachmentViewerModalProps> = ({
  attachment,
  onClose,
}) => {
  const [downloaded, setDownloaded] = React.useState(false);

  if (!attachment) return null;

  const handleDownload = () => {
    setDownloaded(true);
    // Create a real text file download blob so it actually downloads
    const content = `OAKRIDGE ACADEMY OFFICIAL DOCUMENT ARCHIVE\nDocument: ${attachment.name}\nSize: ${attachment.size}\nIssued for School Academic Year 2026\nStatus: Verified institutional clearance.`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = attachment.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    setTimeout(() => setDownloaded(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900 truncate max-w-md">
                {attachment.name}
              </h3>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span>PDF Document</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">{attachment.size}</span>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1 text-emerald-600 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5" /> Verified Campus Asset
                </span>
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Document Preview Canvas */}
        <div className="p-6 overflow-y-auto bg-slate-100 flex-1 flex flex-col items-center">
          <div className="bg-white border border-slate-200 rounded-xl shadow-xs w-full max-w-xl p-8 text-slate-800 font-sans min-h-[380px] flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-slate-200 pb-4 mb-6">
                <div>
                  <div className="text-xs font-bold tracking-wider uppercase text-slate-400">
                    Oakridge Academy Document Depository
                  </div>
                  <h4 className="text-base font-bold text-slate-900 mt-1">
                    {attachment.name.replace(/_/g, ' ').replace('.pdf', '')}
                  </h4>
                </div>
                <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-700 font-mono">
                  OA
                </div>
              </div>

              <div className="space-y-4 text-xs leading-relaxed text-slate-600">
                <p>
                  This official bulletin supplement has been filed by the Department Faculty in accordance with Campus Guidelines. Students and guardians should read all provisions thoroughly.
                </p>
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200 text-slate-700">
                  <div className="font-semibold text-slate-900 mb-1">Key Document Instructions:</div>
                  <ul className="list-disc list-inside space-y-1">
                    <li>Submit signed authorization slips prior to scheduled laboratory or travel times.</li>
                    <li>Refer to Section 3.2 for safety parameters and laboratory attire.</li>
                    <li>Digital submission accepted via school student portal.</li>
                  </ul>
                </div>
                <p className="text-slate-500 italic">
                  Digital Signature: Verified by Department Chair. Stamped: Fall Academic Semester.
                </p>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-xs text-slate-400 font-mono">
              <span>Ref: OA-DOC-2026-F</span>
              <span>Page 1 of 1</span>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-200 bg-white">
          <div className="text-xs text-slate-500">
            Previewing institution-verified document attachment
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              Close
            </button>
            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-xs"
            >
              {downloaded ? (
                <>
                  <Check className="w-4 h-4 text-emerald-200" />
                  Downloaded
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Download File
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
