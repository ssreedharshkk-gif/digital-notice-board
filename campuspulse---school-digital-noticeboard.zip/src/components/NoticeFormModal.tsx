import React, { useState } from 'react';
import {
  X,
  Send,
  Plus,
  Trash2,
  Calendar,
  MapPin,
  FileText,
  HelpCircle,
  Eye,
  Edit3,
  BellRing,
} from 'lucide-react';
import type {
  Notice,
  NoticeCategory,
  NoticePriority,
  TargetGrade,
  NoticeAttachment,
  UserProfile,
} from '../types.ts';

interface NoticeFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (noticeData: any) => void;
  currentUser: UserProfile;
  initialNotice?: Notice | null;
}

const SAMPLE_ATTACHMENTS = [
  { name: 'Laboratory_Safety_Contract_2026.pdf', size: '1.2 MB', type: 'pdf' as const },
  { name: 'Field_Trip_Parental_Consent_Form.pdf', size: '540 KB', type: 'pdf' as const },
  { name: 'Semester_Exam_Review_Outline.pdf', size: '2.4 MB', type: 'pdf' as const },
  { name: 'Audition_Monologue_Sides_Packet.pdf', size: '890 KB', type: 'pdf' as const },
  { name: 'Athletic_Physical_Evaluation.pdf', size: '650 KB', type: 'pdf' as const },
];

export const NoticeFormModal: React.FC<NoticeFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  currentUser,
  initialNotice,
}) => {
  const [title, setTitle] = useState(initialNotice?.title || '');
  const [content, setContent] = useState(initialNotice?.content || '');
  const [category, setCategory] = useState<NoticeCategory>(initialNotice?.category || 'academic');
  const [priority, setPriority] = useState<NoticePriority>(initialNotice?.priority || 'normal');
  const [targetGrade, setTargetGrade] = useState<TargetGrade>(initialNotice?.targetGrade || 'all');
  const [targetDepartment, setTargetDepartment] = useState(
    initialNotice?.targetDepartment || currentUser.department || 'Academic Department'
  );
  const [pinned, setPinned] = useState(initialNotice?.pinned || false);
  const [eventDate, setEventDate] = useState(initialNotice?.eventDate || '');
  const [eventLocation, setEventLocation] = useState(initialNotice?.eventLocation || '');

  // Poll state
  const [enablePoll, setEnablePoll] = useState(!!initialNotice?.poll);
  const [pollQuestion, setPollQuestion] = useState(initialNotice?.poll?.question || '');
  const [pollOptions, setPollOptions] = useState<string[]>(
    initialNotice?.poll ? initialNotice.poll.options.map((o) => o.text) : ['Yes, attending', 'No, unable to attend']
  );

  // Attachments state
  const [attachments, setAttachments] = useState<NoticeAttachment[]>(initialNotice?.attachments || []);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');
  const [chimeOnSend, setChimeOnSend] = useState(priority === 'urgent');

  if (!isOpen) return null;

  const handleAddPollOption = () => {
    if (pollOptions.length < 5) {
      setPollOptions([...pollOptions, `Option ${pollOptions.length + 1}`]);
    }
  };

  const handleRemovePollOption = (idx: number) => {
    setPollOptions(pollOptions.filter((_, i) => i !== idx));
  };

  const handleUpdatePollOption = (idx: number, text: string) => {
    const updated = [...pollOptions];
    updated[idx] = text;
    setPollOptions(updated);
  };

  const handleAddAttachment = (att: typeof SAMPLE_ATTACHMENTS[0]) => {
    if (!attachments.some((a) => a.name === att.name)) {
      setAttachments([...attachments, att]);
    }
  };

  const handleRemoveAttachment = (name: string) => {
    setAttachments(attachments.filter((a) => a.name !== name));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const noticeData: any = {
      title: title.trim(),
      content: content.trim(),
      category,
      priority,
      targetGrade,
      targetDepartment: targetDepartment.trim(),
      pinned,
      authorName: currentUser.name,
      authorRole: currentUser.title,
      eventDate: eventDate.trim() || undefined,
      eventLocation: eventLocation.trim() || undefined,
      attachments: attachments.length > 0 ? attachments : undefined,
      chime: chimeOnSend || priority === 'urgent',
    };

    if (enablePoll && pollQuestion.trim() && pollOptions.length >= 2) {
      noticeData.poll = {
        question: pollQuestion.trim(),
        options: pollOptions
          .filter((t) => t.trim().length > 0)
          .map((text, i) => ({
            id: `opt-${Date.now()}-${i}`,
            text: text.trim(),
            votes: 0,
          })),
        totalVotes: 0,
        voters: {},
      };
    }

    if (initialNotice) {
      noticeData.id = initialNotice.id;
    }

    onSubmit(noticeData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-2xl w-full border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-sm shrink-0">
              {initialNotice ? <Edit3 className="w-4 h-4" /> : <Send className="w-4 h-4" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {initialNotice ? 'Edit School Announcement' : 'Post New School Notice'}
              </h2>
              <div className="text-xs text-slate-500">
                Publishing as <span className="font-semibold text-slate-700">{currentUser.name}</span> ({currentUser.title})
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Edit / Preview Tabs */}
            <div className="flex items-center p-0.5 bg-slate-200 rounded-lg text-xs font-medium">
              <button
                type="button"
                onClick={() => setActiveTab('edit')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'edit' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Compose
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'preview' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Preview
              </button>
            </div>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Form Body */}
        {activeTab === 'edit' ? (
          <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-5 flex-1">
            {/* Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Announcement Title <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., AP Physics Lab Station Schedule & Safety Review"
                className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>

            {/* Categorization Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as NoticeCategory)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  <option value="academic">Academic & Labs</option>
                  <option value="athletics">Athletics & Teams</option>
                  <option value="arts_clubs">Clubs & Arts</option>
                  <option value="administrative">Campus Administration</option>
                  <option value="emergency">Emergency Advisory</option>
                  <option value="exam_schedule">Exams & Schedule</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Priority</label>
                <select
                  value={priority}
                  onChange={(e) => {
                    const val = e.target.value as NoticePriority;
                    setPriority(val);
                    if (val === 'urgent') setChimeOnSend(true);
                  }}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  <option value="normal">Standard Notice</option>
                  <option value="high">High Priority</option>
                  <option value="urgent">Urgent Flash Alert</option>
                  <option value="low">Low / Informational</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">Target Audience</label>
                <select
                  value={targetGrade}
                  onChange={(e) => setTargetGrade(e.target.value as TargetGrade)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                >
                  <option value="all">All School Grades</option>
                  <option value="grade_9">Grade 9 (Freshmen)</option>
                  <option value="grade_10">Grade 10 (Sophomores)</option>
                  <option value="grade_11">Grade 11 (Juniors)</option>
                  <option value="grade_12">Grade 12 (Seniors)</option>
                  <option value="middle_school">Middle School</option>
                  <option value="faculty">Faculty & Staff</option>
                </select>
              </div>
            </div>

            {/* Department tag */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Department / Subject</label>
              <input
                type="text"
                value={targetDepartment}
                onChange={(e) => setTargetDepartment(e.target.value)}
                placeholder="e.g., Natural Sciences, Athletic Dept, Student Affairs"
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
              />
            </div>

            {/* Content Body */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Announcement Content <span className="text-rose-500">*</span>
              </label>
              <textarea
                required
                rows={4}
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder="Write the clear details of the notice, guidelines, room changes, or instructions for students..."
                className="w-full px-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600 leading-relaxed"
              />
            </div>

            {/* Event Time & Location Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Event Date & Time (Optional)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    placeholder="e.g., Monday, Oct 14 at 3:30 PM"
                    className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                  <Calendar className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Campus Location / Venue (Optional)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={eventLocation}
                    onChange={(e) => setEventLocation(e.target.value)}
                    placeholder="e.g., Science Lab 304 / Main Track"
                    className="w-full pl-8 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                  <MapPin className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                </div>
              </div>
            </div>

            {/* Interactive Poll Toggle */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-slate-900 flex items-center gap-1.5">
                    <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                    Attach Interactive Student Poll / RSVP
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Gather quick student feedback or headcounts in real-time
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={enablePoll}
                  onChange={(e) => setEnablePoll(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                />
              </div>

              {enablePoll && (
                <div className="mt-3 space-y-2 pt-3 border-t border-slate-200">
                  <input
                    type="text"
                    value={pollQuestion}
                    onChange={(e) => setPollQuestion(e.target.value)}
                    placeholder="Poll Question (e.g., Which track event are you trying out for?)"
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-600"
                  />
                  <div className="space-y-1.5">
                    {pollOptions.map((opt, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <input
                          type="text"
                          value={opt}
                          onChange={(e) => handleUpdatePollOption(idx, e.target.value)}
                          placeholder={`Option ${idx + 1}`}
                          className="flex-1 px-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-none"
                        />
                        {pollOptions.length > 2 && (
                          <button
                            type="button"
                            onClick={() => handleRemovePollOption(idx)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-md"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                  {pollOptions.length < 5 && (
                    <button
                      type="button"
                      onClick={handleAddPollOption}
                      className="inline-flex items-center gap-1 text-xs text-indigo-600 hover:text-indigo-800 font-medium pt-1"
                    >
                      <Plus className="w-3.5 h-3.5" /> Add Option
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Document Attachments */}
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50">
              <div className="text-xs font-semibold text-slate-900 mb-1 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-indigo-600" />
                Attach Official PDF Documents & Forms
              </div>
              <div className="text-[11px] text-slate-500 mb-3">
                Select quick school document templates:
              </div>

              <div className="flex flex-wrap gap-1.5 mb-3">
                {SAMPLE_ATTACHMENTS.map((s) => {
                  const isSelected = attachments.some((a) => a.name === s.name);
                  return (
                    <button
                      key={s.name}
                      type="button"
                      onClick={() =>
                        isSelected ? handleRemoveAttachment(s.name) : handleAddAttachment(s)
                      }
                      className={`px-2.5 py-1 rounded-md text-xs transition-colors border ${
                        isSelected
                          ? 'bg-indigo-50 border-indigo-300 text-indigo-800 font-medium'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {isSelected ? '✓ ' : '+ '}
                      {s.name.replace('.pdf', '').replace(/_/g, ' ')}
                    </button>
                  );
                })}
              </div>

              {attachments.length > 0 && (
                <div className="text-[11px] text-slate-600">
                  <span className="font-semibold">{attachments.length}</span> attachment(s) will be included.
                </div>
              )}
            </div>

            {/* Pin & Chime Options */}
            <div className="flex items-center justify-between gap-4 pt-2">
              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={pinned}
                  onChange={(e) => setPinned(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                />
                <span>Pin this notice to top of noticeboard</span>
              </label>

              <label className="flex items-center gap-2 text-xs font-medium text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={chimeOnSend}
                  onChange={(e) => setChimeOnSend(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 h-4 w-4"
                />
                <span className="flex items-center gap-1">
                  <BellRing className="w-3.5 h-3.5 text-indigo-600" />
                  Broadcast campus alert chime
                </span>
              </label>
            </div>

            {/* Form Action Buttons */}
            <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="inline-flex items-center gap-2 px-5 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                {initialNotice ? 'Save Changes' : 'Broadcast Notice Live'}
              </button>
            </div>
          </form>
        ) : (
          /* Live Preview Mode */
          <div className="p-6 overflow-y-auto space-y-4 flex-1 bg-slate-50">
            <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Student View Preview:
            </div>
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
              {pinned && (
                <div className="text-xs font-semibold text-indigo-600">Pinned Announcement</div>
              )}
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <span className="font-semibold text-slate-800">{category}</span>
                <span>·</span>
                <span>{targetGrade}</span>
                <span>·</span>
                <span>{targetDepartment}</span>
                <span>·</span>
                <span>Just now</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900">{title || 'Untitled Notice'}</h3>
              <p className="text-sm text-slate-700 leading-relaxed whitespace-pre-line">
                {content || 'Announcement content will appear here...'}
              </p>
              {eventDate && (
                <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-700 flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{eventDate}</span>
                  {eventLocation && <span>at {eventLocation}</span>}
                </div>
              )}
              {enablePoll && pollQuestion && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
                  <div className="font-semibold text-slate-900">{pollQuestion}</div>
                  {pollOptions.map((o, i) => (
                    <div key={i} className="p-2 bg-white rounded border border-slate-200 text-slate-700">
                      {o}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="flex justify-end pt-4">
              <button
                type="button"
                onClick={() => setActiveTab('edit')}
                className="px-4 py-2 text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
              >
                Back to Edit
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
