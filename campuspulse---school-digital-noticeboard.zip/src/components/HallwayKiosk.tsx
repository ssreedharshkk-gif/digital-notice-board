import React, { useState, useEffect } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  QrCode,
  Bell,
  Clock,
  Pin,
  Calendar,
  MapPin,
  X,
  AlertTriangle,
} from 'lucide-react';
import type { Notice } from '../types.ts';

interface HallwayKioskProps {
  notices: Notice[];
  onClose: () => void;
  onlineCount: { total: number; teachers: number; students: number };
}

export const HallwayKiosk: React.FC<HallwayKioskProps> = ({
  notices,
  onClose,
  onlineCount,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [time, setTime] = useState(new Date());

  // Urgent notices strip
  const urgentNotices = notices.filter((n) => n.priority === 'urgent');

  // Active carousel notices (prioritizing pinned and recent)
  const displayNotices = notices.length > 0 ? notices : [];

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (isPaused || displayNotices.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % displayNotices.length);
    }, 8000);

    return () => clearInterval(interval);
  }, [isPaused, displayNotices.length]);

  const activeNotice = displayNotices[currentIndex];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % displayNotices.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + displayNotices.length) % displayNotices.length);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col overflow-hidden select-none">
      {/* Top Header Strip */}
      <header className="px-8 py-5 border-b border-slate-800/80 bg-slate-900/80 backdrop-blur-md flex items-center justify-between gap-6 shrink-0">
        <div className="flex items-center gap-4">
          <img
            src="/src/assets/images/school_emblem_crest_1791618934698.jpg"
            alt="Oakridge Academy Crest"
            referrerPolicy="no-referrer"
            className="w-12 h-12 rounded-xl object-cover border border-amber-500/30 shadow-md"
          />
          <div>
            <div className="text-xl font-black tracking-tight flex items-center gap-2">
              <span>OAKRIDGE ACADEMY</span>
              <span className="text-indigo-400 font-light">DIGITAL COMMONS</span>
            </div>
            <div className="text-xs text-slate-400 font-medium">
              Hallway Noticeboard · Real-Time Campus Information System
            </div>
          </div>
        </div>

        {/* Live Clock & Period Status */}
        <div className="flex items-center gap-8">
          <div className="text-right hidden sm:block">
            <div className="text-2xl font-bold font-mono tracking-wider tabular-nums text-indigo-300">
              {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </div>
            <div className="text-xs text-slate-400 font-medium">
              {time.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric', year: 'numeric' })}
            </div>
          </div>

          <button
            onClick={onClose}
            className="px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors flex items-center gap-1.5 border border-slate-700"
          >
            <X className="w-4 h-4" />
            <span>Exit Kiosk</span>
          </button>
        </div>
      </header>

      {/* Urgent Alert Banner (if any) */}
      {urgentNotices.length > 0 && (
        <div className="bg-rose-950/80 border-b border-rose-800/80 px-8 py-2.5 flex items-center justify-between gap-4 text-rose-200 text-xs shrink-0 animate-pulse">
          <div className="flex items-center gap-2 font-semibold">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>ACTIVE ADVISORY: {urgentNotices[0].title}</span>
          </div>
          <span className="text-rose-300 font-mono text-[11px] shrink-0">
            Issued by {urgentNotices[0].authorName}
          </span>
        </div>
      )}

      {/* Main Kiosk Stage */}
      <main className="flex-1 p-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch overflow-hidden">
        {/* Left Column: Rotating Main Notice Showcase (8 cols) */}
        <section className="lg:col-span-8 flex flex-col justify-between bg-slate-900/60 rounded-3xl border border-slate-800 p-8 shadow-2xl relative overflow-hidden">
          {/* Subtle ambient lighting */}
          <div className="absolute -right-24 -top-24 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

          {activeNotice ? (
            <div className="relative z-10 flex flex-col justify-between h-full space-y-6">
              <div>
                {/* Meta header */}
                <div className="flex items-center justify-between gap-4 mb-4">
                  <div className="flex items-center gap-2 text-xs text-slate-400 font-medium uppercase tracking-wider">
                    {activeNotice.pinned && (
                      <span className="flex items-center gap-1 text-amber-400 font-semibold">
                        <Pin className="w-3.5 h-3.5 fill-amber-400" /> Pinned
                      </span>
                    )}
                    <span>{activeNotice.category}</span>
                    <span>·</span>
                    <span>{activeNotice.targetGrade.replace('_', ' ')}</span>
                  </div>

                  <div className="text-xs font-mono text-slate-500">
                    Notice {currentIndex + 1} of {displayNotices.length}
                  </div>
                </div>

                {/* Notice Title */}
                <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight mb-5">
                  {activeNotice.title}
                </h1>

                {/* Content */}
                <p className="text-lg text-slate-300 leading-relaxed line-clamp-6 mb-6">
                  {activeNotice.content}
                </p>

                {/* Event info */}
                {(activeNotice.eventDate || activeNotice.eventLocation) && (
                  <div className="p-4 bg-slate-800/80 rounded-2xl border border-slate-700/80 flex flex-wrap gap-6 text-sm text-slate-200 mb-6">
                    {activeNotice.eventDate && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-indigo-400" />
                        <span className="font-semibold">{activeNotice.eventDate}</span>
                      </div>
                    )}
                    {activeNotice.eventLocation && (
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-indigo-400" />
                        <span>{activeNotice.eventLocation}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Poll glimpse */}
                {activeNotice.poll && (
                  <div className="p-4 bg-slate-800/60 rounded-2xl border border-slate-700/60">
                    <div className="text-xs text-indigo-300 font-semibold mb-2">
                      Live Student Vote ({activeNotice.poll.totalVotes} responses): {activeNotice.poll.question}
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {activeNotice.poll.options.slice(0, 2).map((opt) => (
                        <div key={opt.id} className="p-2 bg-slate-900 rounded-lg text-slate-300 flex justify-between">
                          <span className="truncate">{opt.text}</span>
                          <span className="font-mono text-indigo-400 ml-2">{opt.votes}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Author Footer */}
              <div className="pt-6 border-t border-slate-800/80 flex items-center justify-between text-sm text-slate-400">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-indigo-600/30 border border-indigo-500/40 text-indigo-200 flex items-center justify-center font-bold">
                    {activeNotice.authorName.charAt(0)}
                  </div>
                  <div>
                    <div className="font-semibold text-white">{activeNotice.authorName}</div>
                    <div className="text-xs text-slate-400">{activeNotice.authorRole}</div>
                  </div>
                </div>

                <div className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span>
                  {activeNotice.acknowledgments.length} Confirmed Read
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-slate-500 text-lg">
              No notices published currently.
            </div>
          )}

          {/* Carousel Controls */}
          <div className="mt-6 flex items-center justify-between pt-4 border-t border-slate-800/60">
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrev}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title="Previous notice"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => setIsPaused(!isPaused)}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title={isPaused ? 'Resume auto-cycle' : 'Pause auto-cycle'}
              >
                {isPaused ? <Play className="w-5 h-5" /> : <Pause className="w-5 h-5" />}
              </button>
              <button
                onClick={handleNext}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                title="Next notice"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Pagination dots */}
            <div className="flex items-center gap-1.5">
              {displayNotices.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIndex(i)}
                  className={`h-2 rounded-full transition-all ${
                    i === currentIndex ? 'w-6 bg-indigo-500' : 'w-2 bg-slate-700 hover:bg-slate-600'
                  }`}
                />
              ))}
            </div>
          </div>
        </section>

        {/* Right Column: Campus Photo, QR Mobile Sync & Bell info (4 cols) */}
        <section className="lg:col-span-4 flex flex-col gap-6 justify-between">
          {/* Hallway Campus Card */}
          <div className="relative rounded-3xl overflow-hidden border border-slate-800 shadow-xl group h-48 lg:h-56">
            <img
              src="/src/assets/images/school_campus_hallway_1791618945729.jpg"
              alt="Oakridge Campus Commons"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover brightness-75 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-5 flex flex-col justify-end">
              <div className="text-xs uppercase tracking-wider font-bold text-indigo-400">
                Main Academic Hall
              </div>
              <div className="text-sm font-semibold text-white">
                Next Bell in 18 minutes · Transition to Period 4
              </div>
            </div>
          </div>

          {/* QR Code Card for Students */}
          <div className="bg-slate-900/60 rounded-3xl border border-slate-800 p-6 flex flex-col items-center text-center">
            <div className="p-3 bg-white rounded-2xl shadow-md mb-3">
              <QrCode className="w-24 h-24 text-slate-900" />
            </div>
            <div className="text-sm font-bold text-white mb-1">
              Take Noticeboard With You
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              Point your student phone camera at this display to bookmark notices and submit RSVPs directly.
            </p>
            <div className="text-[11px] font-mono text-indigo-400 bg-indigo-950/60 px-3 py-1 rounded-full border border-indigo-800/40">
              {onlineCount.total} Connected Students & Staff Live
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};
