import React, { useState } from 'react';
import { X, GraduationCap, School, Check, UserPlus } from 'lucide-react';
import type { UserProfile } from '../types.ts';

interface ProfileSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onSelectUser: (user: UserProfile) => void;
}

const PRESET_TEACHERS: UserProfile[] = [
  {
    id: 'teacher-thorne',
    name: 'Dr. Aris Thorne',
    role: 'teacher',
    title: 'Science Dept Chair & AP Chemistry Instructor',
    department: 'Natural Sciences',
    email: 'a.thorne@oakridge.edu',
  },
  {
    id: 'teacher-brody',
    name: 'Coach Marcus Brody',
    role: 'teacher',
    title: 'Athletic Director & Head Track Coach',
    department: 'Athletics & PE',
    email: 'm.brody@oakridge.edu',
  },
  {
    id: 'teacher-jenkins',
    name: 'Sarah Jenkins, M.Ed.',
    role: 'teacher',
    title: 'Vice Principal & Operations Director',
    department: 'Dean of Students Office',
    email: 's.jenkins@oakridge.edu',
  },
  {
    id: 'teacher-rostova',
    name: 'Ms. Elena Rostova',
    role: 'teacher',
    title: 'Drama Department Lead & Performing Arts',
    department: 'Fine Arts',
    email: 'e.rostova@oakridge.edu',
  },
];

const PRESET_STUDENTS: UserProfile[] = [
  {
    id: 'student-101',
    name: 'Leo Vance',
    role: 'student',
    title: 'Grade 11 Student (STEM & AP Scholar)',
    grade: 'grade_11',
    email: 'l.vance@student.oakridge.edu',
  },
  {
    id: 'student-102',
    name: 'Maya Patel',
    role: 'student',
    title: 'Grade 10 Student (Fine Arts & Drama Club)',
    grade: 'grade_10',
    email: 'm.patel@student.oakridge.edu',
  },
  {
    id: 'student-103',
    name: 'Jordan Smith',
    role: 'student',
    title: 'Grade 12 Senior (Varsity Athletics Captain)',
    grade: 'grade_12',
    email: 'j.smith@student.oakridge.edu',
  },
  {
    id: 'student-104',
    name: 'Chris Evans',
    role: 'student',
    title: 'Grade 9 Freshman (Robotics & Science Club)',
    grade: 'grade_9',
    email: 'c.evans@student.oakridge.edu',
  },
];

export const ProfileSwitcherModal: React.FC<ProfileSwitcherModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onSelectUser,
}) => {
  const [customName, setCustomName] = useState('');
  const [customRole, setCustomRole] = useState<'teacher' | 'student'>('teacher');
  const [customTitle, setCustomTitle] = useState('');

  if (!isOpen) return null;

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim()) return;

    const newProfile: UserProfile = {
      id: `user-custom-${Date.now()}`,
      name: customName.trim(),
      role: customRole,
      title: customTitle.trim() || (customRole === 'teacher' ? 'Faculty Instructor' : 'High School Student'),
      department: customRole === 'teacher' ? 'General Faculty' : undefined,
      grade: customRole === 'student' ? 'grade_11' : undefined,
    };

    onSelectUser(newProfile);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-lg w-full border border-slate-200 shadow-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div>
            <h3 className="text-base font-bold text-slate-900">Switch Role & User Profile</h3>
            <p className="text-xs text-slate-500">
              Test both sides: Post notices as a Teacher, or view & react as a Student in real-time.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Profiles list */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {/* Teachers Section */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
              <School className="w-3.5 h-3.5 text-indigo-600" />
              <span>Faculty & Teachers (Post & Manage Notices)</span>
            </div>
            <div className="space-y-2">
              {PRESET_TEACHERS.map((teacher) => {
                const isCurrent = currentUser.id === teacher.id;
                return (
                  <button
                    key={teacher.id}
                    onClick={() => {
                      onSelectUser(teacher);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-colors text-xs ${
                      isCurrent
                        ? 'bg-indigo-50/80 border-indigo-300 ring-1 ring-indigo-200'
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center shrink-0">
                        {teacher.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-slate-900 truncate">{teacher.name}</div>
                        <div className="text-slate-500 truncate">{teacher.title}</div>
                      </div>
                    </div>
                    {isCurrent && <Check className="w-4 h-4 text-indigo-600 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Students Section */}
          <div>
            <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-500 mb-2.5">
              <GraduationCap className="w-3.5 h-3.5 text-emerald-600" />
              <span>Students (View, Acknowledge & Vote)</span>
            </div>
            <div className="space-y-2">
              {PRESET_STUDENTS.map((student) => {
                const isCurrent = currentUser.id === student.id;
                return (
                  <button
                    key={student.id}
                    onClick={() => {
                      onSelectUser(student);
                      onClose();
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-colors text-xs ${
                      isCurrent
                        ? 'bg-emerald-50/80 border-emerald-300 ring-1 ring-emerald-200'
                        : 'bg-white hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center shrink-0">
                        {student.name.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-slate-900 truncate">{student.name}</div>
                        <div className="text-slate-500 truncate">{student.title}</div>
                      </div>
                    </div>
                    {isCurrent && <Check className="w-4 h-4 text-emerald-600 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Custom Persona Builder */}
          <div className="pt-3 border-t border-slate-200">
            <div className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
              <UserPlus className="w-3.5 h-3.5 text-slate-500" />
              Or Create a Custom User Profile
            </div>
            <form onSubmit={handleCreateCustom} className="space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  placeholder="Full Name (e.g., Prof. Clark)"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                <select
                  value={customRole}
                  onChange={(e) => setCustomRole(e.target.value as any)}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                >
                  <option value="teacher">Teacher / Faculty</option>
                  <option value="student">Student</option>
                </select>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Title or Department / Grade"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                <button
                  type="submit"
                  disabled={!customName.trim()}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-900 disabled:opacity-50 text-white font-semibold rounded-lg transition-colors shrink-0"
                >
                  Set Active
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
