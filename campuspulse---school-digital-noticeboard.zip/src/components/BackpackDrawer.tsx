import React from 'react';
import { X, Bookmark, Trash2, Calendar, FileText } from 'lucide-react';
import type { Notice } from '../types.ts';

interface BackpackDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  savedNotices: Notice[];
  onRemoveSaved: (id: string) => void;
  onSelectNotice: (id: string) => void;
}

export const BackpackDrawer: React.FC<BackpackDrawerProps> = ({
  isOpen,
  onClose,
  savedNotices,
  onRemoveSaved,
  onSelectNotice,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/50 backdrop-blur-xs">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col border-l border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
              <Bookmark className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-slate-900">My Student Backpack</h3>
              <div className="text-xs text-slate-500 font-mono tabular-nums">
                {savedNotices.length} saved notice{savedNotices.length === 1 ? '' : 's'}
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          {savedNotices.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <Bookmark className="w-10 h-10 mx-auto text-slate-300 mb-3" />
              <div className="text-sm font-semibold text-slate-700">Backpack is Empty</div>
              <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                Click the bookmark button on any notice card to save exam guides, schedule changes, and club tryouts here.
              </p>
            </div>
          ) : (
            savedNotices.map((notice) => (
              <div
                key={notice.id}
                className="p-4 rounded-xl border border-slate-200 hover:border-indigo-200 bg-white hover:bg-slate-50/60 transition-colors shadow-2xs group relative"
              >
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1.5">
                  <span className="font-semibold text-slate-700 capitalize">{notice.category}</span>
                  <button
                    onClick={() => onRemoveSaved(notice.id)}
                    className="text-slate-400 hover:text-rose-600 transition-colors p-1"
                    title="Remove from backpack"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <h4
                  onClick={() => {
                    onSelectNotice(notice.id);
                    onClose();
                  }}
                  className="text-sm font-bold text-slate-900 hover:text-indigo-600 cursor-pointer line-clamp-2 mb-2 leading-snug"
                >
                  {notice.title}
                </h4>

                {notice.eventDate && (
                  <div className="flex items-center gap-1.5 text-xs text-indigo-600 font-medium mb-2">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{notice.eventDate}</span>
                  </div>
                )}

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                  <span>By {notice.authorName}</span>
                  {notice.attachments && notice.attachments.length > 0 && (
                    <span className="flex items-center gap-1 text-slate-600">
                      <FileText className="w-3 h-3 text-indigo-500" />
                      {notice.attachments.length} file(s)
                    </span>
                  )}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
