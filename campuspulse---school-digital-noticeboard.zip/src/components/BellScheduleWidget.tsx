import React, { useState, useEffect } from 'react';
import { Clock, ChevronDown, ChevronUp, Bell } from 'lucide-react';

interface PeriodInfo {
  name: string;
  start: string; // HH:MM
  end: string;   // HH:MM
  label: string;
}

const SCHEDULE: PeriodInfo[] = [
  { name: 'Period 1', start: '08:00', end: '08:50', label: 'Morning Core' },
  { name: 'Period 2', start: '08:55', end: '09:45', label: 'Languages & Humanities' },
  { name: 'Advisory', start: '09:50', end: '10:15', label: 'Homeroom & Announcements' },
  { name: 'Period 3', start: '10:20', end: '11:10', label: 'STEM & Natural Sciences' },
  { name: 'Period 4 / Lunch', start: '11:15', end: '12:25', label: 'Midday Block & Commons' },
  { name: 'Period 5', start: '12:30', end: '13:20', label: 'Social Studies & Arts' },
  { name: 'Period 6', start: '13:25', end: '14:15', label: 'Mathematics & Electives' },
  { name: 'Period 7', start: '14:20', end: '15:10', label: 'Study Seminar' },
  { name: 'After School', start: '15:15', end: '17:30', label: 'Athletics & Club Activities' },
];

export const BellScheduleWidget: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentTimeStr, setCurrentTimeStr] = useState('');
  const [currentPeriod, setCurrentPeriod] = useState<PeriodInfo | null>(null);

  useEffect(() => {
    const update = () => {
      const now = new Date();
      const hours = String(now.getHours()).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const currentHhMm = `${hours}:${minutes}`;
      setCurrentTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));

      const found = SCHEDULE.find((p) => currentHhMm >= p.start && currentHhMm < p.end);
      setCurrentPeriod(found || SCHEDULE[2]); // Fallback to advisory if outside normal hours
    };

    update();
    const interval = setInterval(update, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center shrink-0">
            <Bell className="w-4 h-4 text-indigo-600" />
          </div>
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
              <span>Campus Bell Schedule</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums text-slate-700">{currentTimeStr}</span>
            </div>
            <div className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <span>{currentPeriod?.name ?? 'Passing Period'}</span>
              <span className="text-slate-400 font-normal">({currentPeriod?.label})</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors shrink-0"
        >
          <span>{isOpen ? 'Hide Schedule' : 'View All Periods'}</span>
          {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </button>
      </div>

      {isOpen && (
        <div className="mt-3 pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2">
          {SCHEDULE.map((p) => {
            const isNow = currentPeriod?.name === p.name;
            return (
              <div
                key={p.name}
                className={`p-2 rounded-lg text-xs transition-colors ${
                  isNow
                    ? 'bg-indigo-50 border border-indigo-200 text-indigo-900 font-medium'
                    : 'bg-slate-50 text-slate-600'
                }`}
              >
                <div className="flex items-center justify-between font-mono tabular-nums">
                  <span className="font-semibold">{p.name}</span>
                  <span className="text-slate-500">{p.start} - {p.end}</span>
                </div>
                <div className="truncate text-slate-500 mt-0.5">{p.label}</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
