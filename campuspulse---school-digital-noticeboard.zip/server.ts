import express from 'express';
import http from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import type { Notice, UserProfile, OnlinePresence } from './src/types.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

// Initial rich seed data for a vibrant school environment
let notices: Notice[] = [
  {
    id: 'notice-1',
    title: 'AP Chemistry Lab Practical: Revised Station Schedule & Safety Protocols',
    content: 'All AP Chemistry students in Periods 3 and 5 must report directly to Science Lab 304. Full PPE (approved splash goggles, closed-toe footwear, and tied-back hair) is strictly required at the door. Station rotations will operate on a strict 18-minute cycle. Please review the pre-lab titration rubric attached.',
    category: 'academic',
    priority: 'high',
    targetGrade: 'grade_11',
    targetDepartment: 'Natural Sciences',
    authorName: 'Dr. Aris Thorne',
    authorRole: 'Science Dept Chair & AP Chemistry Instructor',
    createdAt: new Date(Date.now() - 1000 * 60 * 42).toISOString(), // 42 mins ago
    pinned: true,
    eventDate: '2026-10-12 at 09:30 AM',
    eventLocation: 'Science Wing Lab 304',
    attachments: [
      {
        name: 'AP_Chem_Lab_Practical_Rubric_v2.pdf',
        size: '1.4 MB',
        type: 'pdf',
        downloadLabel: 'Titration Rubric'
      },
      {
        name: 'Safety_Checklist_Station_Rules.pdf',
        size: '420 KB',
        type: 'pdf',
        downloadLabel: 'Safety Rules'
      }
    ],
    acknowledgments: ['student-101', 'student-102', 'student-104', 'student-108', 'student-112'],
    reactions: {
      helpful: 24,
      saved: 18,
      applause: 6,
      attending: 32
    },
    userReactions: {}
  },
  {
    id: 'notice-2',
    title: 'Varsity Track & Field Spring Tryout Registration & Medical Clearance',
    content: 'Conditioning week kicks off next Monday at 3:45 PM on the main track. All athletes must ensure their FHSAA physical evaluation form is submitted to Nurse Ramirez before stepping onto the oval. Spike checks will take place at locker bank C.',
    category: 'athletics',
    priority: 'normal',
    targetGrade: 'all',
    targetDepartment: 'Athletics & Physical Education',
    authorName: 'Coach Marcus Brody',
    authorRole: 'Athletic Director & Head Track Coach',
    createdAt: new Date(Date.now() - 1000 * 60 * 180).toISOString(), // 3 hours ago
    pinned: false,
    eventDate: '2026-10-15 at 03:45 PM',
    eventLocation: 'West Campus Stadium & Track',
    poll: {
      question: 'Which track & field disciplines are you planning to compete in?',
      options: [
        { id: 'opt-1', text: 'Sprints & Relays (100m, 200m, 4x100m)', votes: 29 },
        { id: 'opt-2', text: 'Middle Distance & Cross Country (800m, 1600m)', votes: 14 },
        { id: 'opt-3', text: 'Field Events (Long Jump, Shot Put, Javelin)', votes: 19 },
        { id: 'opt-4', text: 'Hurdles & Steeplechase', votes: 8 }
      ],
      totalVotes: 70,
      voters: {}
    },
    attachments: [
      {
        name: 'Athletic_Clearance_Form_2026.pdf',
        size: '680 KB',
        type: 'pdf',
        downloadLabel: 'Medical Form'
      }
    ],
    acknowledgments: ['student-101', 'student-103', 'student-105', 'student-106'],
    reactions: {
      helpful: 35,
      saved: 22,
      applause: 41,
      attending: 45
    },
    userReactions: {}
  },
  {
    id: 'notice-3',
    title: 'Notice of Inclement Weather Advisory: Afternoon Activity Schedule',
    content: 'Due to forecasted thunderstorm activity across the county after 2:30 PM, all outdoor athletic practices and after-school bike commuter pickups will move indoors. Buses will depart on standard schedule at 3:15 PM. Extended study hall in the Media Center will remain open until 5:00 PM.',
    category: 'emergency',
    priority: 'urgent',
    targetGrade: 'all',
    targetDepartment: 'Dean of Students Office',
    authorName: 'Sarah Jenkins, M.Ed.',
    authorRole: 'Vice Principal & Operations Director',
    createdAt: new Date(Date.now() - 1000 * 60 * 95).toISOString(), // 1.5 hours ago
    pinned: true,
    eventLocation: 'Campus-wide / Main Atrium',
    acknowledgments: ['student-101', 'student-102', 'student-103', 'student-104', 'student-105', 'student-106', 'student-107', 'student-108'],
    reactions: {
      helpful: 89,
      saved: 34,
      applause: 12,
      attending: 0
    },
    userReactions: {}
  },
  {
    id: 'notice-4',
    title: 'Auditions for Spring Stage Production: "The Crucible" Callbacks',
    content: 'Audition sides and sheet music packets are now ready for pickup in Black Box Theater Room 112. Initial auditions will occur on Wednesday from 3:30 PM to 6:00 PM. No prior theater experience required—all grade levels are encouraged to audition for onstage roles or technical crew.',
    category: 'arts_clubs',
    priority: 'normal',
    targetGrade: 'all',
    targetDepartment: 'Fine Arts & Dramatic Expression',
    authorName: 'Ms. Elena Rostova',
    authorRole: 'Drama Department Lead',
    createdAt: new Date(Date.now() - 1000 * 60 * 360).toISOString(),
    pinned: false,
    eventDate: '2026-10-14 at 03:30 PM',
    eventLocation: 'Black Box Theater (Room 112)',
    attachments: [
      {
        name: 'The_Crucible_Audition_Sides_Packet.pdf',
        size: '2.1 MB',
        type: 'pdf',
        downloadLabel: 'Audition Packet'
      }
    ],
    poll: {
      question: 'Are you auditioning for Acting or Tech Crew (Stagehand, Lighting, Costumes)?',
      options: [
        { id: 'opt-acting', text: 'Onstage Acting Role', votes: 22 },
        { id: 'opt-tech', text: 'Stage Management & Lighting', votes: 15 },
        { id: 'opt-both', text: 'Interested in Both', votes: 9 }
      ],
      totalVotes: 46,
      voters: {}
    },
    acknowledgments: ['student-102', 'student-103', 'student-109'],
    reactions: {
      helpful: 27,
      saved: 38,
      applause: 51,
      attending: 30
    },
    userReactions: {}
  },
  {
    id: 'notice-5',
    title: 'Regional STEM Science Fair Project Proposal Milestone 1 Due Friday',
    content: 'All students enrolled in Honors Biology, AP Physics, and Research Seminar: your initial Hypothesis & Bibliography submission is due on Friday by 11:59 PM. Mentors will conduct 10-minute check-ins during Thursday advisory periods.',
    category: 'academic',
    priority: 'high',
    targetGrade: 'grade_10',
    targetDepartment: 'STEM Department',
    authorName: 'Dr. Evelyn Martinez',
    authorRole: 'STEM Research Coordinator',
    createdAt: new Date(Date.now() - 1000 * 60 * 480).toISOString(),
    pinned: false,
    eventDate: '2026-10-16 at 11:59 PM',
    eventLocation: 'Digital Portal / Rm 204',
    acknowledgments: ['student-101', 'student-104'],
    reactions: {
      helpful: 41,
      saved: 63,
      applause: 8,
      attending: 21
    },
    userReactions: {}
  },
  {
    id: 'notice-6',
    title: 'Media Center Quiet Study Hours & Peer Math Tutoring Schedule',
    content: 'National Honor Society peer tutors in Algebra I/II, Pre-Calculus, and AP Calculus BC are available every Tuesday and Thursday afternoon from 3:15 PM to 4:45 PM in the North Commons. Study pods can be reserved in 45-minute blocks.',
    category: 'exam_schedule',
    priority: 'normal',
    targetGrade: 'all',
    targetDepartment: 'Academic Support & Library Services',
    authorName: 'Mrs. Miriam Vance',
    authorRole: 'Head Librarian & Academic Resource Lead',
    createdAt: new Date(Date.now() - 1000 * 60 * 720).toISOString(),
    pinned: false,
    eventLocation: 'Media Center North Commons',
    acknowledgments: ['student-103', 'student-107'],
    reactions: {
      helpful: 33,
      saved: 49,
      applause: 19,
      attending: 16
    },
    userReactions: {}
  }
];

// Active client presence tracking
interface ClientMeta {
  ws: WebSocket;
  user?: UserProfile;
}
const clients = new Map<WebSocket, ClientMeta>();

function getPresence(): OnlinePresence {
  let teachers = 0;
  let students = 0;
  for (const meta of clients.values()) {
    if (meta.user?.role === 'teacher') teachers++;
    else students++;
  }
  // Ensure realistic non-zero floor for school ambiance
  return {
    total: Math.max(clients.size, 14),
    teachers: Math.max(teachers, 3),
    students: Math.max(students, 11),
  };
}

function broadcast(message: object, excludeWs?: WebSocket) {
  const payload = JSON.stringify(message);
  for (const [ws] of clients) {
    if (ws !== excludeWs && ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}

wss.on('connection', (ws: WebSocket) => {
  clients.set(ws, { ws });

  // Send initial full state immediately
  ws.send(JSON.stringify({
    type: 'initial_state',
    notices,
    onlineCount: getPresence(),
  }));

  // Notify everyone of updated presence
  broadcast({
    type: 'presence_updated',
    onlineCount: getPresence(),
  });

  ws.on('message', (data: string) => {
    try {
      const msg = JSON.parse(data.toString());

      if (msg.type === 'init_presence') {
        const meta = clients.get(ws);
        if (meta) {
          meta.user = msg.user;
          broadcast({
            type: 'presence_updated',
            onlineCount: getPresence(),
          });
        }
      } else if (msg.type === 'create_notice') {
        const newNotice: Notice = {
          ...msg.notice,
          id: 'notice-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          createdAt: new Date().toISOString(),
          acknowledgments: [],
          reactions: { helpful: 0, saved: 0, applause: 0, attending: 0 },
          userReactions: {},
        };
        // Add to front of array
        notices = [newNotice, ...notices];
        // Broadcast to all clients including sender
        const broadcastPayload = {
          type: 'notice_created',
          notice: newNotice,
        };
        for (const [clientWs] of clients) {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify(broadcastPayload));
          }
        }
      } else if (msg.type === 'update_notice') {
        const updated = msg.notice as Notice;
        notices = notices.map((n) => (n.id === updated.id ? { ...n, ...updated } : n));
        const broadcastPayload = {
          type: 'notice_updated',
          notice: updated,
        };
        for (const [clientWs] of clients) {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify(broadcastPayload));
          }
        }
      } else if (msg.type === 'delete_notice') {
        const { id } = msg;
        notices = notices.filter((n) => n.id !== id);
        const broadcastPayload = {
          type: 'notice_deleted',
          id,
        };
        for (const [clientWs] of clients) {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify(broadcastPayload));
          }
        }
      } else if (msg.type === 'toggle_pin') {
        const { id } = msg;
        let targetPinned = false;
        notices = notices.map((n) => {
          if (n.id === id) {
            targetPinned = !n.pinned;
            return { ...n, pinned: targetPinned };
          }
          return n;
        });
        const broadcastPayload = {
          type: 'notice_pinned',
          id,
          pinned: targetPinned,
        };
        for (const [clientWs] of clients) {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify(broadcastPayload));
          }
        }
      } else if (msg.type === 'acknowledge_notice') {
        const { id, userId } = msg;
        const target = notices.find((n) => n.id === id);
        if (target) {
          if (!target.acknowledgments.includes(userId)) {
            target.acknowledgments.push(userId);
          } else {
            target.acknowledgments = target.acknowledgments.filter((uid) => uid !== userId);
          }
          const broadcastPayload = {
            type: 'notice_acknowledged',
            id,
            acknowledgments: target.acknowledgments,
          };
          for (const [clientWs] of clients) {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify(broadcastPayload));
            }
          }
        }
      } else if (msg.type === 'react_notice') {
        const { id, reactionType, userId } = msg;
        const target = notices.find((n) => n.id === id);
        if (target && (reactionType in target.reactions)) {
          if (!target.userReactions) target.userReactions = {};
          const userList = target.userReactions[userId] || [];
          const hasReacted = userList.includes(reactionType);

          if (hasReacted) {
            // Remove reaction
            target.userReactions[userId] = userList.filter((r) => r !== reactionType);
            target.reactions[reactionType as keyof typeof target.reactions] = Math.max(
              0,
              target.reactions[reactionType as keyof typeof target.reactions] - 1
            );
          } else {
            // Add reaction
            target.userReactions[userId] = [...userList, reactionType];
            target.reactions[reactionType as keyof typeof target.reactions] += 1;
          }

          const broadcastPayload = {
            type: 'notice_reacted',
            id,
            reactions: target.reactions,
            userId,
            userReactions: target.userReactions[userId],
          };
          for (const [clientWs] of clients) {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify(broadcastPayload));
            }
          }
        }
      } else if (msg.type === 'vote_poll') {
        const { noticeId, optionId, userId } = msg;
        const target = notices.find((n) => n.id === noticeId);
        if (target && target.poll) {
          if (!target.poll.voters) target.poll.voters = {};
          const previousVote = target.poll.voters[userId];

          if (previousVote === optionId) {
            // Toggle off vote
            delete target.poll.voters[userId];
            const opt = target.poll.options.find((o) => o.id === optionId);
            if (opt) opt.votes = Math.max(0, opt.votes - 1);
            target.poll.totalVotes = Math.max(0, target.poll.totalVotes - 1);
          } else {
            // Remove previous vote if any
            if (previousVote) {
              const prevOpt = target.poll.options.find((o) => o.id === previousVote);
              if (prevOpt) prevOpt.votes = Math.max(0, prevOpt.votes - 1);
            } else {
              target.poll.totalVotes += 1;
            }
            // Add new vote
            target.poll.voters[userId] = optionId;
            const newOpt = target.poll.options.find((o) => o.id === optionId);
            if (newOpt) newOpt.votes += 1;
          }

          const broadcastPayload = {
            type: 'poll_voted',
            id: noticeId,
            poll: target.poll,
          };
          for (const [clientWs] of clients) {
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify(broadcastPayload));
            }
          }
        }
      } else if (msg.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong' }));
      }
    } catch (err) {
      console.error('Error handling WS message:', err);
    }
  });

  ws.on('close', () => {
    clients.delete(ws);
    broadcast({
      type: 'presence_updated',
      onlineCount: getPresence(),
    });
  });
});

// REST Fallback API endpoints
app.get('/api/notices', (req, res) => {
  res.json({ notices, onlineCount: getPresence() });
});

app.post('/api/notices', (req, res) => {
  const newNotice: Notice = {
    ...req.body,
    id: 'notice-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    createdAt: new Date().toISOString(),
    acknowledgments: [],
    reactions: { helpful: 0, saved: 0, applause: 0, attending: 0 },
    userReactions: {},
  };
  notices = [newNotice, ...notices];
  broadcast({ type: 'notice_created', notice: newNotice });
  res.status(201).json(newNotice);
});

app.delete('/api/notices/:id', (req, res) => {
  const { id } = req.params;
  notices = notices.filter((n) => n.id !== id);
  broadcast({ type: 'notice_deleted', id });
  res.json({ success: true });
});

// Development vs Production server setup
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  server.listen(port, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${port} (mode: ${isDev ? 'development' : 'production'})`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
